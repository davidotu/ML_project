# Movie_Recommender_system

![Untitled design](https://user-images.githubusercontent.com/101575355/227784312-1d7f88fb-6695-4eb1-b1a7-bcf46b8120cc.png)
